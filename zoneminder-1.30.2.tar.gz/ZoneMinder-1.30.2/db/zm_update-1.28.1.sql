ALTER TABLE Monitors MODIFY Device tinytext;
