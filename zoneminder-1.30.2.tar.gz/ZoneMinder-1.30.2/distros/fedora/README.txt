Fedora rpm build files have been merged with redhat.
See /distros/redhat.

