The latest version of these docs can be found at http://zoneminder.readthedocs.org/
