Options - Display
-----------------

.. image:: images/Options_Display.png

This option screen allows user to select the skin for ZoneMinder. Currently available skins are:

* Classic
* Flat
* XML (Deprecated in favour of web/API)
* Mobile (Deprecated)


